import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  PoundSterling,
  CalendarSync,
  LayoutDashboard,
  ShieldCheck,
  SlidersHorizontal,
  Zap,
  Star,
  Users,
  BadgeCheck,
  CreditCard,
  Handshake,
  MapPin,
  TrendingDown,
} from "lucide-react";

const features = [
  {
    icon: PoundSterling,
    title: "Low Booking Fees",
    description:
      "Keep more of what you earn. Our fees are significantly lower than the big platforms — so every booking works harder for you.",
    highlight: "Lower than Airbnb & Booking.com",
  },
  {
    icon: CalendarSync,
    title: "Calendar Sync",
    description:
      "Sync your availability automatically with Airbnb, Booking.com and other platforms. No double bookings, no manual updates.",
    highlight: "Airbnb · Booking.com · iCal",
  },
  {
    icon: LayoutDashboard,
    title: "Owner Dashboard",
    description:
      "Manage every booking, track your earnings month by month, and see your performance at a glance — all in one place.",
    highlight: "Built for property owners",
  },
  {
    icon: ShieldCheck,
    title: "Guest Review Protection",
    description:
      "You review your guests. Every guest builds a verified Trust Score based on host feedback, so you always know who's arriving.",
    highlight: "You're in control",
  },
  {
    icon: SlidersHorizontal,
    title: "Flexible Booking Control",
    description:
      "Set your own minimum stay, instant book or request-only, seasonal rates, and block out personal dates — total flexibility.",
    highlight: "Your rules, your property",
  },
  {
    icon: Zap,
    title: "Easy Setup",
    description:
      "Add your property, photos, and availability in under 15 minutes. Our guided setup walks you through every step.",
    highlight: "Live in under 15 minutes",
  },
];

const whyUs = [
  {
    icon: BadgeCheck,
    title: "Verified Guest Trust Scores",
    body: "Owners review guests after every stay. Those reviews build a verified Trust Score that travels with each guest — so you always know who you're welcoming.",
    colour: "bg-emerald-50 text-emerald-700",
    iconBg: "bg-emerald-100",
  },
  {
    icon: CreditCard,
    title: "Flexible Instalment Payments",
    body: "Guests can spread their holiday cost across three instalments. That means more bookings for you — especially for longer or higher-value stays.",
    colour: "bg-blue-50 text-blue-700",
    iconBg: "bg-blue-100",
  },
  {
    icon: Handshake,
    title: "Direct Owner Connection",
    body: "Guests book directly with you. No call centres, no faceless corporation — just a more personal, trusted experience that earns better reviews.",
    colour: "bg-violet-50 text-violet-700",
    iconBg: "bg-violet-100",
  },
  {
    icon: MapPin,
    title: "Local Experiences Marketplace",
    body: "Every stay comes with a curated local directory — nearby businesses, events, and things to do. Guests love it, and it makes your listing stand out.",
    colour: "bg-amber-50 text-amber-700",
    iconBg: "bg-amber-100",
  },
  {
    icon: TrendingDown,
    title: "Lower Fees Than the Big Platforms",
    body: "Airbnb and Booking.com take a significant cut. We don't. Our lower commission means more money in your pocket on every single booking.",
    colour: "bg-rose-50 text-rose-700",
    iconBg: "bg-rose-100",
  },
];

const testimonials = [
  {
    name: "Margaret H.",
    location: "Cotswolds, Oxfordshire",
    quote:
      "The calendar sync alone is worth it — no more double bookings. And the fees are so much lower than what I was paying elsewhere.",
    rating: 5,
    earnings: "£2,400/mo",
  },
  {
    name: "David K.",
    location: "St Ives, Cornwall",
    quote:
      "The guest trust score system gives me real peace of mind. I can see a guest's review history before I accept — something Airbnb doesn't offer.",
    rating: 5,
    earnings: "£1,800/mo",
  },
  {
    name: "Fiona M.",
    location: "Edinburgh, Scotland",
    quote:
      "Setup took me about 10 minutes. The dashboard is brilliant — I can see everything in one place and the support team actually picks up the phone.",
    rating: 5,
    earnings: "£3,100/mo",
  },
];

const steps = [
  { number: "01", title: "Create Your Listing", detail: "Add photos, description, amenities and your nightly rate." },
  { number: "02", title: "Sync Your Calendar", detail: "Connect Airbnb, Booking.com or paste your iCal link." },
  { number: "03", title: "Start Accepting Bookings", detail: "Review guests, confirm bookings, and get paid." },
];

export default function Advertise() {
  return (
    <div className="w-full flex flex-col">

      {/* ── HERO ─────────────────────────────────────────────────── */}
      <section className="relative w-full bg-primary overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(255,255,255,0.12)_0%,_transparent_65%)]" />
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-primary/80 to-transparent" />
        </div>

        <div className="container mx-auto px-4 py-28 md:py-40 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-4xl mx-auto"
          >
            <span className="inline-block bg-white/15 border border-white/25 text-white text-sm font-semibold px-5 py-2 rounded-full mb-8 tracking-widest uppercase">
              For Property Owners
            </span>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-6 leading-tight">
              List Your Holiday Property
            </h1>
            <p className="text-white/85 text-xl md:text-2xl max-w-2xl mx-auto mb-12 leading-relaxed">
              Low fees. Calendar sync. Guest reviews. Everything you need to earn more
              from your UK holiday rental — and keep more of every pound.
            </p>
            <Button
              size="lg"
              className="bg-white text-primary hover:bg-white/90 font-bold h-16 px-12 text-lg shadow-2xl rounded-xl"
              asChild
            >
              <Link href="/register">
                List Your Holiday Property
                <ArrowRight className="ml-3 h-6 w-6" />
              </Link>
            </Button>
            <p className="text-white/60 text-sm mt-4">Free to list · No setup fees · Cancel anytime</p>
          </motion.div>
        </div>
      </section>

      {/* ── STATS ────────────────────────────────────────────────── */}
      <section className="bg-white border-b border-border py-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "£1,800+", label: "Avg. monthly earnings" },
              { value: "< 3%", label: "Owner booking fee" },
              { value: "15 min", label: "Average setup time" },
              { value: "12,000+", label: "Active UK guests" },
            ].map((s) => (
              <div key={s.label}>
                <p className="text-3xl md:text-4xl font-serif font-bold text-primary">{s.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ─────────────────────────────────────────────── */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              From your first listing to full occupancy — staticholidays gives you the tools
              the big platforms don't.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.45, delay: i * 0.08 }}
              >
                <Card className="h-full border border-border hover:shadow-lg transition-shadow">
                  <CardContent className="p-7 flex flex-col gap-4 h-full">
                    <div className="h-12 w-12 bg-primary/10 rounded-xl flex items-center justify-center">
                      <f.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-foreground mb-1">{f.title}</h3>
                      <span className="inline-block text-xs font-semibold text-primary bg-primary/8 px-2.5 py-0.5 rounded-full mb-3">
                        {f.highlight}
                      </span>
                      <p className="text-muted-foreground leading-relaxed">{f.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-14">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white h-14 px-12 text-base font-bold rounded-xl shadow-lg" asChild>
              <Link href="/register">
                List Your Holiday Property
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ── WHY CHOOSE US ────────────────────────────────────────── */}
      <section className="py-24 bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
              Why Choose staticholidays?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              We built this platform for owners like you — not for Wall Street. Here's
              what makes us genuinely different.
            </p>
          </div>

          <div className="max-w-5xl mx-auto space-y-6">
            {whyUs.map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <Card className="border border-border bg-white">
                  <CardContent className="p-7 flex gap-6 items-start">
                    <div className={`h-14 w-14 rounded-2xl flex items-center justify-center flex-shrink-0 ${item.iconBg}`}>
                      <item.icon className={`h-7 w-7 ${item.colour.split(" ")[1]}`} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-foreground mb-2">{item.title}</h3>
                      <p className="text-muted-foreground leading-relaxed text-base">{item.body}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ─────────────────────────────────────────── */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
              Up and Running in Three Steps
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-4xl mx-auto">
            {steps.map((s, i) => (
              <div key={s.number} className="flex flex-col items-center text-center">
                <div className="relative mb-6">
                  <div className="h-20 w-20 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
                    <span className="text-white font-serif text-3xl font-bold">{s.number}</span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className="hidden md:block absolute top-10 left-full w-full h-0.5 bg-border -translate-y-1/2" />
                  )}
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{s.title}</h3>
                <p className="text-muted-foreground">{s.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ─────────────────────────────────────────── */}
      <section className="py-24 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
              Owners Love staticholidays
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Real property owners sharing real results.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {testimonials.map((t) => (
              <Card key={t.name} className="border border-border bg-white">
                <CardContent className="p-7 flex flex-col gap-4">
                  <div className="flex gap-1">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="text-foreground leading-relaxed italic flex-1">"{t.quote}"</p>
                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div>
                      <p className="font-bold text-foreground">{t.name}</p>
                      <p className="text-sm text-muted-foreground">{t.location}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary text-xl">{t.earnings}</p>
                      <p className="text-xs text-muted-foreground">avg. earnings</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ── INCLUDED ─────────────────────────────────────────────── */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-14">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
                Everything Included, Free to List
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                "Low owner booking fee",
                "Calendar sync with Airbnb & Booking.com",
                "Owner dashboard with earnings chart",
                "Guest trust score visibility before you accept",
                "Guest instalment payments supported",
                "Instant booking notifications",
                "Flexible booking control (instant or request)",
                "Seasonal and weekend pricing",
                "Availability calendar management",
                "Full guest and property review system",
                "Local businesses and events listings",
                "UK-based owner support, 7 days a week",
              ].map((f) => (
                <div key={f} className="flex items-center gap-3 p-4 rounded-lg border border-border bg-muted/40">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-foreground font-medium">{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ────────────────────────────────────────────── */}
      <section className="py-28 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6 max-w-3xl mx-auto leading-tight">
            Ready to List Your Holiday Property?
          </h2>
          <p className="text-white/80 text-xl max-w-xl mx-auto mb-12 leading-relaxed">
            Join thousands of UK owners already earning more with staticholidays.
            Free to list. No contracts. Cancel anytime.
          </p>
          <Button
            size="lg"
            className="bg-white text-primary hover:bg-white/90 font-bold h-16 px-14 text-lg shadow-2xl rounded-xl"
            asChild
          >
            <Link href="/register">
              List Your Holiday Property
              <ArrowRight className="ml-3 h-6 w-6" />
            </Link>
          </Button>
          <p className="text-white/50 text-sm mt-5">No credit card required</p>
        </div>
      </section>

    </div>
  );
}
