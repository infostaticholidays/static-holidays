import { useListProducts } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingBag } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Shop() {
  const [category, setCategory] = useState<string>("");
  const { data: products, isLoading } = useListProducts({ category: category || undefined });

  const categories = ["Gifts", "Experiences", "Accessories", "Clothing"];

  if (isLoading) return <div className="container mx-auto p-8 text-center">Loading shop...</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-serif font-bold text-foreground mb-4">The staticholidays Shop</h1>
        <p className="text-lg text-muted-foreground">Bring a piece of your holiday home with our curated collection of British goods.</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-8 justify-center">
        <Button 
          variant={category === "" ? "default" : "outline"} 
          onClick={() => setCategory("")}
          className="rounded-full"
        >
          All
        </Button>
        {categories.map(c => (
          <Button 
            key={c}
            variant={category === c ? "default" : "outline"} 
            onClick={() => setCategory(c)}
            className="rounded-full"
          >
            {c}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products?.map(product => (
          <Link key={product.id} href={`/shop/${product.id}`}>
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer overflow-hidden border-border group">
              <div className="h-64 overflow-hidden relative bg-muted flex items-center justify-center p-4">
                <img 
                  src={product.imageUrl || "/images/trust-badge.png"} 
                  alt={product.name} 
                  className="max-w-full max-h-full object-contain group-hover:scale-105 transition-transform duration-500"
                />
                {product.featured && (
                  <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground border-none">
                    Featured
                  </Badge>
                )}
              </div>
              <CardContent className="p-5 flex flex-col items-center text-center">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">{product.category}</p>
                <h3 className="text-lg font-serif font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">{product.name}</h3>
                <div className="mt-auto pt-4 w-full flex justify-between items-center">
                  <span className="font-bold text-lg text-foreground">£{product.price}</span>
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <ShoppingBag className="h-4 w-4" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
        {(!products || products.length === 0) && (
          <div className="col-span-full text-center py-12 text-muted-foreground">
            No products found in this category.
          </div>
        )}
      </div>
    </div>
  );
}
