import { useGetProduct } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { ShoppingBag, ArrowLeft, Package, Truck, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ShopDetail() {
  const { id } = useParams();
  const productId = parseInt(id || "0", 10);
  const { data: product, isLoading } = useGetProduct(productId, { query: { enabled: !!productId } });
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();

  if (isLoading) return <div className="container mx-auto p-8">Loading product...</div>;
  if (!product) return <div className="container mx-auto p-8">Product not found</div>;

  const handleAddToCart = () => {
    toast({
      title: "Added to basket",
      description: `${quantity}x ${product.name} has been added to your order.`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <Link href="/shop" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-8 transition-colors">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Shop
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-muted rounded-2xl p-8 flex items-center justify-center min-h-[400px]">
          <img 
            src={product.imageUrl || "/images/trust-badge.png"} 
            alt={product.name} 
            className="max-w-full max-h-full object-contain mix-blend-multiply"
          />
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <Badge variant="outline" className="text-primary border-primary/20 uppercase tracking-wider">{product.category}</Badge>
              {product.stock < 10 && <span className="text-sm text-destructive font-medium">Low stock</span>}
            </div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">{product.name}</h1>
            <p className="text-3xl font-bold text-foreground mb-6">£{product.price}</p>
            <p className="text-lg text-muted-foreground leading-relaxed">{product.description}</p>
          </div>

          <div className="py-6 border-y border-border">
            <div className="flex items-center gap-4 mb-6">
              <span className="font-medium">Quantity</span>
              <div className="flex items-center border border-border rounded-md">
                <Button variant="ghost" size="icon" className="h-10 w-10 rounded-none" onClick={() => setQuantity(Math.max(1, quantity - 1))}>-</Button>
                <div className="w-12 text-center font-medium">{quantity}</div>
                <Button variant="ghost" size="icon" className="h-10 w-10 rounded-none" onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}>+</Button>
              </div>
            </div>

            <Button 
              className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              onClick={handleAddToCart}
            >
              <ShoppingBag className="mr-2 h-5 w-5" /> Add to Basket
            </Button>
          </div>

          <div className="space-y-4 pt-2">
            <div className="flex items-start gap-3 text-sm text-muted-foreground">
              <Truck className="h-5 w-5 text-primary shrink-0" />
              <p>Free UK delivery on orders over £50. Standard delivery 2-3 working days.</p>
            </div>
            <div className="flex items-start gap-3 text-sm text-muted-foreground">
              <Package className="h-5 w-5 text-primary shrink-0" />
              <p>Eco-friendly packaging. We use 100% recyclable materials.</p>
            </div>
            <div className="flex items-start gap-3 text-sm text-muted-foreground">
              <ShieldCheck className="h-5 w-5 text-primary shrink-0" />
              <p>Secure checkout. 30-day return policy for unused items.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
