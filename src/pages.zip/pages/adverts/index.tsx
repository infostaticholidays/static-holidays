import { useListAdverts } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Phone, Globe, Mail } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Adverts() {
  const [category, setCategory] = useState<string>("all");
  const { data: adverts, isLoading } = useListAdverts({
    category: category !== "all" ? category : undefined
  });

  const categories = ["Restaurant", "Cafe", "Pub", "Activity", "Service", "Shop"];

  if (isLoading) return <div className="container mx-auto p-8 text-center">Loading directory...</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-serif font-bold text-foreground mb-4">Local Directory</h1>
        <p className="text-lg text-muted-foreground">Support local businesses near your stay. Hand-picked recommendations for the best experiences.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8 justify-center">
        <div className="w-full md:w-64">
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="bg-background">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(c => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {adverts?.map(advert => (
          <Card key={advert.id} className="overflow-hidden border-border hover:shadow-md transition-shadow flex flex-col h-full">
            <div className="h-48 overflow-hidden relative bg-muted">
              <img 
                src={advert.imageUrl || "/images/cottage.png"} 
                alt={advert.businessName} 
                className="w-full h-full object-cover"
              />
              <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground border-none">
                {advert.category}
              </Badge>
              {advert.featured && (
                <Badge className="absolute top-3 left-3 bg-accent text-accent-foreground border-none">
                  Recommended
                </Badge>
              )}
            </div>
            <CardContent className="p-5 flex-1 flex flex-col">
              <h3 className="text-xl font-serif font-bold mb-2">{advert.businessName}</h3>
              <p className="text-sm text-muted-foreground mb-4 flex-1 line-clamp-3">{advert.description}</p>
              
              <div className="space-y-2 text-sm">
                <p className="flex items-center gap-2 text-foreground">
                  <MapPin className="h-4 w-4 text-primary" /> {advert.location}{advert.county ? `, ${advert.county}` : ''}
                </p>
                <p className="flex items-center gap-2 text-foreground">
                  <Phone className="h-4 w-4 text-primary" /> {advert.contactPhone}
                </p>
                {advert.contactEmail && (
                  <p className="flex items-center gap-2 text-foreground">
                    <Mail className="h-4 w-4 text-primary" /> {advert.contactEmail}
                  </p>
                )}
                {advert.website && (
                  <p className="flex items-center gap-2 text-primary hover:underline">
                    <Globe className="h-4 w-4" /> 
                    <a href={advert.website} target="_blank" rel="noopener noreferrer">Visit Website</a>
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        {(!adverts || adverts.length === 0) && (
          <div className="col-span-full text-center py-12 text-muted-foreground">
            No businesses found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
}
