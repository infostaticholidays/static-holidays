import { PropertyCard } from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useListProperties } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { Search, MapPin, Filter, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function Properties() {
  const [location, ] = useLocation();
  
  // Extract query params
  const searchParams = new URLSearchParams(window.location.search);
  const initialLocation = searchParams.get('location') || '';
  
  const [searchQuery, setSearchQuery] = useState(initialLocation);
  const [activeLocation, setActiveLocation] = useState(initialLocation);
  const [propertyType, setPropertyType] = useState<string>("all");
  const [petFriendly, setPetFriendly] = useState(false);
  
  const { data, isLoading } = useListProperties({
    location: activeLocation || undefined,
    propertyType: propertyType !== "all" ? propertyType : undefined,
    petFriendly: petFriendly ? true : undefined,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveLocation(searchQuery);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Find Your Perfect Stay</h1>
        
        {/* Search and Filters */}
        <div className="bg-card border border-border rounded-xl p-4 md:p-6 shadow-sm mb-8">
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5" />
              <Input 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Where do you want to go?" 
                className="pl-10 h-12 bg-background text-base"
              />
            </div>
            <Button type="submit" className="h-12 px-8 text-base bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
              <Search className="mr-2 h-5 w-5" /> Search
            </Button>
          </form>
          
          <div className="flex flex-wrap items-center gap-6 pt-4 border-t border-border">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            
            <Select value={propertyType} onValueChange={setPropertyType}>
              <SelectTrigger className="w-[180px] h-10 bg-background">
                <SelectValue placeholder="Property Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="cottage">Cottage</SelectItem>
                <SelectItem value="apartment">Apartment</SelectItem>
                <SelectItem value="house">House</SelectItem>
                <SelectItem value="cabin">Cabin</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex items-center space-x-2 bg-background border border-border rounded-md px-3 h-10">
              <Switch id="pet-friendly" checked={petFriendly} onCheckedChange={setPetFriendly} />
              <Label htmlFor="pet-friendly" className="text-sm cursor-pointer">Pet Friendly</Label>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div>
        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-foreground">
            {isLoading ? "Searching..." : `${data?.total || 0} properties found`}
          </h2>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-[400px] bg-muted animate-pulse rounded-xl" />
            ))}
          </div>
        ) : data?.properties && data.properties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.properties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          <div className="text-center py-24 bg-card border border-border rounded-xl shadow-sm">
            <div className="mx-auto w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">No properties found</h3>
            <p className="text-muted-foreground max-w-md mx-auto mb-6">
              We couldn't find any properties matching your current filters. Try adjusting your search criteria.
            </p>
            <Button variant="outline" onClick={() => {
              setSearchQuery("");
              setActiveLocation("");
              setPropertyType("all");
              setPetFriendly(false);
            }}>
              Clear all filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
