import { useGetProperty, useGetPropertyReviews, useCreateBooking } from "@workspace/api-client-react";
import { useParams, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Users, BedDouble, Bath, Check, Calendar as CalendarIcon, Info } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

export default function PropertyDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const propertyId = parseInt(id || "0", 10);
  
  const { data: property, isLoading } = useGetProperty(propertyId, {
    query: { enabled: !!propertyId }
  });
  
  const { data: reviews } = useGetPropertyReviews(propertyId, {
    query: { enabled: !!propertyId }
  });

  const [date, setDate] = useState<Date | undefined>(new Date());
  const [guests, setGuests] = useState(1);
  const [useInstalments, setUseInstalments] = useState(false);

  const createBookingMutation = useCreateBooking({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Booking requested successfully!" });
        setLocation(`/bookings/${data.id}`);
      },
      onError: (error) => {
        toast({ 
          title: "Booking failed", 
          description: error.message || "Please try again later.",
          variant: "destructive"
        });
      }
    }
  });

  const handleBook = () => {
    if (!user) {
      toast({ title: "Please log in to book", variant: "destructive" });
      setLocation("/login");
      return;
    }
    
    if (!date) {
      toast({ title: "Please select a date", variant: "destructive" });
      return;
    }

    const checkOut = new Date(date);
    checkOut.setDate(checkOut.getDate() + 3); // Default 3 nights for demo

    createBookingMutation.mutate({
      data: {
        propertyId,
        checkIn: date.toISOString(),
        checkOut: checkOut.toISOString(),
        guests,
        instalmentPlan: useInstalments,
      }
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="h-8 w-1/3 bg-muted animate-pulse rounded mb-4" />
        <div className="h-[400px] bg-muted animate-pulse rounded-xl mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            <div className="h-4 w-full bg-muted animate-pulse rounded" />
            <div className="h-4 w-5/6 bg-muted animate-pulse rounded" />
          </div>
          <div className="h-[300px] bg-muted animate-pulse rounded-xl" />
        </div>
      </div>
    );
  }

  if (!property) {
    return <div className="container mx-auto py-24 text-center">Property not found</div>;
  }

  const imageUrl = property.images?.[0] || "/images/cottage.png";

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-6">
        <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-2">{property.title}</h1>
        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1 font-medium text-foreground">
            <Star className="h-4 w-4 fill-primary text-primary" />
            {property.averageRating ? property.averageRating.toFixed(1) : "New"}
          </span>
          <span className="flex items-center gap-1 underline underline-offset-2">
            {property.reviewCount || 0} reviews
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {property.location}{property.county ? `, ${property.county}` : ""}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10 h-[50vh] min-h-[400px]">
        <div className="h-full rounded-l-xl overflow-hidden">
          <img src={imageUrl} alt={property.title} className="w-full h-full object-cover" />
        </div>
        <div className="grid grid-rows-2 gap-4 h-full">
          <div className="rounded-tr-xl overflow-hidden">
            <img src={property.images?.[1] || "/images/apartment.png"} alt="Interior" className="w-full h-full object-cover" />
          </div>
          <div className="rounded-br-xl overflow-hidden">
            <img src={property.images?.[2] || "/images/coastal.png"} alt="View" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-serif font-bold mb-2">Hosted by {property.hostName || "Host"}</h2>
              <div className="flex items-center gap-4 text-muted-foreground">
                <span className="flex items-center gap-1"><Users className="h-4 w-4" /> {property.maxGuests} guests</span>
                <span className="flex items-center gap-1"><BedDouble className="h-4 w-4" /> {property.bedrooms} bedrooms</span>
                <span className="flex items-center gap-1"><Bath className="h-4 w-4" /> {property.bathrooms} baths</span>
              </div>
            </div>
            <Avatar className="h-14 w-14 border border-border">
              <AvatarImage src={property.hostAvatarUrl || ""} />
              <AvatarFallback>{property.hostName?.charAt(0) || "H"}</AvatarFallback>
            </Avatar>
          </div>

          <Separator />

          <div>
            <h3 className="text-xl font-serif font-bold mb-4">About this space</h3>
            <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
              {property.description}
            </p>
          </div>

          <Separator />

          <div>
            <h3 className="text-xl font-serif font-bold mb-4">What this place offers</h3>
            <div className="grid grid-cols-2 gap-4">
              {property.amenities?.map((amenity, i) => (
                <div key={i} className="flex items-center gap-3 text-muted-foreground">
                  <Check className="h-5 w-5 text-primary" />
                  <span className="capitalize">{amenity}</span>
                </div>
              ))}
              {property.petFriendly && (
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Check className="h-5 w-5 text-primary" />
                  <span>Pet Friendly</span>
                </div>
              )}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-xl font-serif font-bold mb-4 flex items-center gap-2">
              <Star className="h-5 w-5 fill-primary text-primary" />
              {property.averageRating ? property.averageRating.toFixed(1) : "No reviews yet"} 
              <span className="text-base font-normal text-muted-foreground ml-2">({property.reviewCount || 0} reviews)</span>
            </h3>
            
            <div className="space-y-6">
              {reviews?.map((review) => (
                <div key={review.id} className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={review.guestAvatarUrl || ""} />
                      <AvatarFallback>{review.guestName?.charAt(0) || "G"}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold">{review.guestName}</h4>
                      <p className="text-sm text-muted-foreground">{format(new Date(review.createdAt), "MMMM yyyy")}</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <Card className="sticky top-24 border-border shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-end gap-1 mb-6">
                <span className="text-2xl font-bold text-foreground">£{property.pricePerNight}</span>
                <span className="text-muted-foreground">/ night</span>
              </div>

              <div className="space-y-4 mb-6">
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="p-3 border-b border-border bg-muted/30">
                    <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">Check-in Date</label>
                    <div className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">{date ? format(date, "PPP") : "Select date"}</span>
                    </div>
                  </div>
                  <div className="p-3 bg-muted/30 flex justify-between items-center">
                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">Guests</label>
                      <span className="text-sm font-medium">{guests} guest{guests > 1 ? "s" : ""}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setGuests(Math.max(1, guests - 1))}>-</Button>
                      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setGuests(Math.min(property.maxGuests, guests + 1))}>+</Button>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-muted/50 rounded-lg border border-border">
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox" 
                      id="instalment" 
                      className="mt-1 accent-primary"
                      checked={useInstalments}
                      onChange={(e) => setUseInstalments(e.target.checked)}
                    />
                    <div>
                      <label htmlFor="instalment" className="font-semibold text-sm cursor-pointer block mb-1">
                        Pay in 3 Instalments
                      </label>
                      <p className="text-xs text-muted-foreground">
                        Secure your booking today with just a 33% deposit. Pay the rest later.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Button 
                className="w-full h-12 text-base bg-primary hover:bg-primary/90 text-primary-foreground font-semibold mb-4"
                onClick={handleBook}
                disabled={createBookingMutation.isPending}
              >
                {createBookingMutation.isPending ? "Booking..." : "Reserve"}
              </Button>

              <div className="text-center text-sm text-muted-foreground">
                You won't be charged yet
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
