import {
  useGetDashboardStats,
  useGetDashboardEarnings,
  useListProperties,
  useListBookings,
} from "@workspace/api-client-react";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";

import {
  Home,
  PoundSterling,
  CalendarCheck,
  Star,
  Activity,
} from "lucide-react";

import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PropertyCard } from "@/components/PropertyCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format, differenceInDays } from "date-fns";

const trustScore = 98;
const nextHoliday = new Date("2026-08-15");
const daysRemaining = differenceInDays(nextHoliday, new Date());

const localEvents = [
  { name: "Cornwall Food Festival", date: "2026-08-16" },
  { name: "Coastal Kayaking Tour", date: "2026-08-17" },
  { name: "Sunset Harbour Cruise", date: "2026-08-18" },
];

export default function Dashboard() {
  const { data: stats } = useGetDashboardStats();
  const { data: earnings } = useGetDashboardEarnings();
  const { data: propertiesData } = useListProperties();
  const { data: bookingsData } = useListBookings({ role: "host" });

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <h1 className="text-4xl font-bold mb-8">Dashboard</h1>

      <Tabs defaultValue="overview">
        <TabsList className="mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="guest">Guest Area</TabsTrigger>
          <TabsTrigger value="properties">Properties</TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
        </TabsList>

        {/* OVERVIEW */}

        <TabsContent value="overview">
          <div className="grid grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <PoundSterling />
                <h2>£{stats?.totalEarnings || 0}</h2>
                <p>Total Earnings</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <CalendarCheck />
                <h2>{stats?.activeBookings || 0}</h2>
                <p>Bookings</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <Home />
                <h2>{stats?.totalProperties || 0}</h2>
                <p>Properties</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <Star />
                <h2>{stats?.averageRating || 0}</h2>
                <p>Rating</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Earnings Overview</CardTitle>
            </CardHeader>

            <CardContent className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={earnings?.monthly || []}>
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Area dataKey="amount" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* GUEST */}

        <TabsContent value="guest">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Holiday Countdown</CardTitle>
            </CardHeader>
            <CardContent>{daysRemaining} days until your holiday</CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Your Trust Score</CardTitle>
            </CardHeader>
            <CardContent>{trustScore}/100</CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Events Near Your Stay</CardTitle>
            </CardHeader>
            <CardContent>
              {localEvents.map((event) => (
                <div key={event.name} className="mb-4">
                  <p>{event.name}</p>
                  <p>{event.date}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* PROPERTIES */}

        <TabsContent value="properties">
          <div className="grid grid-cols-3 gap-6">
            {propertiesData?.properties?.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </TabsContent>

        {/* BOOKINGS */}

        <TabsContent value="bookings">
          {bookingsData?.map((booking) => (
            <Card key={booking.id} className="mb-4">
              <CardContent className="p-6 flex justify-between">
                <div>
                  <h3>{booking.propertyTitle}</h3>
                  <p>{booking.guestName}</p>
                  <p>
                    {format(new Date(booking.checkIn), "PPP")} -
                    {format(new Date(booking.checkOut), "PPP")}
                  </p>
                </div>

                <div>
                  <Badge>{booking.status}</Badge>
                  <p>£{booking.totalPrice}</p>
                  <Button>Manage</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
