import { useGetGuestTrustScore, useGetGuestReviews } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Star, Calendar, MessageSquare, ThumbsUp, Sparkles } from "lucide-react";
import { format } from "date-fns";

export default function Profile() {
  const { id } = useParams();
  const userId = parseInt(id || "0", 10);

  const { data: trustScore, isLoading: scoreLoading } = useGetGuestTrustScore(userId, { query: { enabled: !!userId } });
  const { data: reviews, isLoading: reviewsLoading } = useGetGuestReviews(userId, { query: { enabled: !!userId } });

  if (scoreLoading || reviewsLoading) return <div className="container mx-auto p-8 text-center">Loading profile...</div>;
  if (!trustScore) return <div className="container mx-auto p-8 text-center">Profile not found</div>;

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left Sidebar - Identity Card */}
        <div className="md:col-span-1 space-y-6">
          <Card className="overflow-hidden border-none shadow-lg bg-card">
            <div className="h-32 bg-primary/20 relative">
              <div className="absolute -bottom-12 left-1/2 -translate-x-1/2">
                <Avatar className="h-24 w-24 border-4 border-background shadow-md">
                  <AvatarFallback className="bg-primary text-primary-foreground text-3xl font-serif">
                    G
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
            <CardContent className="pt-16 pb-8 px-6 text-center">
              <h1 className="text-2xl font-serif font-bold mb-1">Guest Profile</h1>
              <p className="text-muted-foreground text-sm flex items-center justify-center gap-1 mb-6">
                <Calendar className="h-4 w-4" /> 
                Joined {trustScore.memberSince ? format(new Date(trustScore.memberSince), "MMMM yyyy") : "Recently"}
              </p>

              <div className="flex flex-col gap-3">
                {trustScore.verifiedIdentity && (
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <ShieldCheck className="h-5 w-5 text-primary" />
                    <span className="font-medium text-sm">Identity Verified</span>
                  </div>
                )}
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Star className="h-5 w-5 text-primary fill-primary" />
                  <span className="font-medium text-sm">{trustScore.totalReviews} Reviews</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md bg-secondary/30">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Trust Badges
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {trustScore.badges?.map((badge, idx) => (
                  <Badge key={idx} className="bg-primary text-primary-foreground py-1 px-3">
                    {badge}
                  </Badge>
                ))}
                {(!trustScore.badges || trustScore.badges.length === 0) && (
                  <p className="text-sm text-muted-foreground">Building trust history</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Content - Stats & Reviews */}
        <div className="md:col-span-2 space-y-8">
          <div>
            <h2 className="text-3xl font-serif font-bold mb-6">Trust Score</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-card p-6 rounded-xl border border-border shadow-sm text-center">
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Score</p>
                <p className="text-3xl font-bold text-primary">{trustScore.score}/100</p>
              </div>
              <div className="bg-card p-6 rounded-xl border border-border shadow-sm text-center">
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Rating</p>
                <div className="flex items-center justify-center gap-1 text-3xl font-bold">
                  {trustScore.averageRating ? trustScore.averageRating.toFixed(1) : "-"}
                  <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-serif font-bold mb-6 flex items-center gap-2">
              <MessageSquare className="h-6 w-6 text-muted-foreground" />
              Reviews from Hosts
            </h3>
            
            <div className="space-y-4">
              {reviews?.map(review => (
                <Card key={review.id} className="border-border shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10 border border-border">
                          <AvatarImage src={review.hostAvatarUrl || ""} />
                          <AvatarFallback>{review.hostName?.charAt(0) || "H"}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{review.hostName}</p>
                          <p className="text-xs text-muted-foreground">{format(new Date(review.createdAt), "MMM yyyy")}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 bg-muted/50 px-2 py-1 rounded-md">
                        <Star className="h-3.5 w-3.5 fill-primary text-primary" />
                        <span className="font-bold text-sm">{review.rating.toFixed(1)}</span>
                      </div>
                    </div>
                    
                    <p className="text-foreground leading-relaxed">"{review.comment}"</p>
                    
                    <div className="mt-4 pt-4 border-t border-border flex gap-4 text-sm text-muted-foreground">
                      {review.cleanliness && (
                        <div className="flex items-center gap-1">
                          <span className="font-medium">Cleanliness:</span> {review.cleanliness}/5
                        </div>
                      )}
                      {review.communication && (
                        <div className="flex items-center gap-1">
                          <span className="font-medium">Communication:</span> {review.communication}/5
                        </div>
                      )}
                      {review.respect && (
                        <div className="flex items-center gap-1">
                          <span className="font-medium">Respect:</span> {review.respect}/5
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {(!reviews || reviews.length === 0) && (
                <div className="text-center py-12 bg-card border border-border rounded-xl">
                  <ThumbsUp className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-20" />
                  <p className="text-lg font-medium text-foreground">No reviews yet</p>
                  <p className="text-muted-foreground">This guest hasn't received any reviews from hosts.</p>
                </div>
              )}
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
