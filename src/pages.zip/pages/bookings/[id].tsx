import { useGetBooking, useGetPaymentPlan, usePayInstalment } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { CreditCard, Calendar, CheckCircle2, CircleDashed } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BookingDetail() {
  const { id } = useParams();
  const bookingId = parseInt(id || "0", 10);
  const { toast } = useToast();

  const { data: booking, isLoading: bookingLoading } = useGetBooking(bookingId, {
    query: { enabled: !!bookingId }
  });

  const { data: paymentPlan, refetch: refetchPaymentPlan } = useGetPaymentPlan(bookingId, {
    query: { enabled: !!bookingId && !!booking?.instalmentPlan }
  });

  const payMutation = usePayInstalment({
    mutation: {
      onSuccess: () => {
        toast({ title: "Payment successful" });
        refetchPaymentPlan();
      },
      onError: (error) => {
        toast({ title: "Payment failed", description: error.message, variant: "destructive" });
      }
    }
  });

  if (bookingLoading) return <div className="container mx-auto p-8">Loading...</div>;
  if (!booking) return <div className="container mx-auto p-8">Booking not found</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl font-serif font-bold mb-6">Booking #{booking.id}</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>{booking.propertyTitle}</span>
                <Badge>{booking.status}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4 p-4 bg-muted/30 rounded-lg">
                <Calendar className="h-5 w-5 text-primary shrink-0" />
                <div>
                  <p className="font-medium">
                    {format(new Date(booking.checkIn), "PPP")} - {format(new Date(booking.checkOut), "PPP")}
                  </p>
                  <p className="text-sm text-muted-foreground">{booking.guests} Guests</p>
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Host</p>
                <p className="font-medium">{booking.hostName}</p>
              </div>
            </CardContent>
          </Card>

          {booking.instalmentPlan && paymentPlan && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" /> Payment Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {paymentPlan.instalments.map((inst, idx) => (
                    <div key={inst.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {inst.status === 'paid' ? (
                          <CheckCircle2 className="h-5 w-5 text-primary" />
                        ) : (
                          <CircleDashed className="h-5 w-5 text-muted-foreground" />
                        )}
                        <div>
                          <p className="font-medium">Instalment {idx + 1}</p>
                          <p className="text-sm text-muted-foreground">Due: {format(new Date(inst.dueDate), "PPP")}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-bold">£{inst.amount}</span>
                        {inst.status === 'pending' && (
                          <Button 
                            size="sm" 
                            onClick={() => payMutation.mutate({ id: bookingId, data: { instalmentId: inst.id } })}
                            disabled={payMutation.isPending}
                          >
                            Pay Now
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Payment Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total</span>
                <span className="font-bold">£{booking.totalPrice}</span>
              </div>
              <div className="flex justify-between text-primary">
                <span>Paid</span>
                <span>£{booking.amountPaid || 0}</span>
              </div>
              <div className="pt-4 border-t flex justify-between font-bold text-lg">
                <span>Remaining</span>
                <span>£{booking.totalPrice - (booking.amountPaid || 0)}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
