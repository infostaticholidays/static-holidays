import { useListBookings } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Calendar, MapPin, CreditCard } from "lucide-react";

export default function Bookings() {
  const { data: bookings, isLoading } = useListBookings({ role: "guest" });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-serif font-bold mb-8">My Bookings</h1>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-40 bg-muted animate-pulse rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-8">My Bookings</h1>

      {!bookings || bookings.length === 0 ? (
        <div className="text-center py-24 bg-card border border-border rounded-xl shadow-sm">
          <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-serif font-bold text-foreground mb-2">No bookings yet</h3>
          <p className="text-muted-foreground mb-6">Time to plan your next British escape.</p>
          <Button asChild>
            <Link href="/properties">Explore Properties</Link>
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {bookings.map((booking) => (
            <Card key={booking.id} className="overflow-hidden border-border hover:shadow-md transition-shadow">
              <div className="flex flex-col md:flex-row">
                <div className="w-full md:w-1/3 h-48 md:h-auto bg-muted">
                  <img 
                    src={booking.propertyImageUrl || "/images/cottage.png"} 
                    alt={booking.propertyTitle} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-serif font-bold line-clamp-1">{booking.propertyTitle}</h3>
                      <Badge variant="outline" className={
                        booking.status === 'confirmed' ? 'bg-primary/10 text-primary border-primary/20' : 
                        booking.status === 'pending' ? 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20' :
                        'bg-muted text-muted-foreground'
                      }>
                        {booking.status.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <p className="text-muted-foreground flex items-center gap-1.5 text-sm mb-4">
                      <MapPin className="h-4 w-4" /> {booking.propertyLocation}
                    </p>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="space-y-1">
                        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Dates</span>
                        <p className="text-sm font-medium">
                          {format(new Date(booking.checkIn), "MMM d")} - {format(new Date(booking.checkOut), "MMM d, yyyy")}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Total</span>
                        <p className="text-sm font-medium">£{booking.totalPrice}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                    {booking.instalmentPlan && (
                      <div className="flex items-center gap-2 text-sm text-primary font-medium">
                        <CreditCard className="h-4 w-4" />
                        Instalment Plan Active
                      </div>
                    )}
                    <Button variant="outline" asChild className="ml-auto">
                      <Link href={`/bookings/${booking.id}`}>View Details</Link>
                    </Button>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
