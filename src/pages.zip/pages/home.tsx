import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PropertyCard } from "@/components/PropertyCard";
import { useGetFeaturedProperties } from "@workspace/api-client-react";
import { Link, useLocation } from "wouter";
import {
  Search,
  MapPin,
  Calendar,
  Users,
  ShieldCheck,
  Heart,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";

export default function Home() {
  const [, setLocation] = useLocation();
  const [locationStr, setLocationStr] = useState("");
  const { data: featuredProperties, isLoading } = useGetFeaturedProperties();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (locationStr) {
      setLocation(`/properties?location=${encodeURIComponent(locationStr)}`);
    } else {
      setLocation("/properties");
    }
  };

  return (
    <div className="w-full flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative w-full h-[85vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black/40 z-10" />
          <img
            src="/images/cottage.png"
            alt="Beautiful British Countryside Cottage"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="container relative z-20 mx-auto px-4 flex flex-col items-center text-center mt-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white mb-6 drop-shadow-lg max-w-4xl">
              Discover the Heart of British Hospitality
            </h1>
            <p className="text-lg md:text-2xl text-white/90 mb-10 max-w-2xl font-medium drop-shadow-md">
              Book trusted UK holiday homes with verified hosts, guest trust
              scores, flexible payments, and local experiences.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full max-w-4xl bg-white p-4 rounded-xl shadow-xl"
          >
            <form
              onSubmit={handleSearch}
              className="flex flex-col md:flex-row gap-4 items-center"
            >
              <div className="flex-1 w-full flex items-center bg-muted/50 rounded-lg px-4 py-3 border border-border">
                <MapPin className="text-muted-foreground mr-3 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Where are you going? (e.g. Cornwall, Cotswolds)"
                  className="border-none bg-transparent shadow-none focus-visible:ring-0 p-0 text-base"
                  value={locationStr}
                  onChange={(e) => setLocationStr(e.target.value)}
                />
              </div>
              <div className="flex-1 w-full flex items-center bg-muted/50 rounded-lg px-4 py-3 border border-border">
                <Calendar className="text-muted-foreground mr-3 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Dates"
                  className="border-none bg-transparent shadow-none focus-visible:ring-0 p-0 text-base"
                />
              </div>
              <div className="flex-1 w-full flex items-center bg-muted/50 rounded-lg px-4 py-3 border border-border">
                <Users className="text-muted-foreground mr-3 h-5 w-5" />
                <Input
                  type="number"
                  placeholder="Guests"
                  min="1"
                  className="border-none bg-transparent shadow-none focus-visible:ring-0 p-0 text-base"
                />
              </div>
              <Button
                type="submit"
                className="w-full md:w-auto h-14 px-8 text-lg font-semibold bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Search className="mr-2 h-5 w-5" />
                Search
              </Button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6">
              <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 text-primary">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-serif font-bold mb-3 text-foreground">
                Verified Hosts & Properties
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Every property on Static Holidays is verified, and our trust
                scoring system ensures a reliable experience.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6">
              <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 text-primary">
                <Heart className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-serif font-bold mb-3 text-foreground">
                Quintessentially British
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                From cozy Cotswolds cottages to sleek London apartments,
                experience the best of UK living.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6">
              <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 text-primary">
                <Sparkles className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-serif font-bold mb-3 text-foreground">
                Premium Experience
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Flexible instalment payments, 24/7 UK-based support, and curated
                local recommendations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
                Featured Escapes
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl">
                Discover our handpicked selection of exceptional properties for
                your next getaway.
              </p>
            </div>
            <Button
              variant="outline"
              className="hidden md:flex font-medium"
              asChild
            >
              <Link href="/properties">View All</Link>
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="h-[400px] bg-muted animate-pulse rounded-xl"
                />
              ))}
            </div>
          ) : featuredProperties && featuredProperties.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProperties.slice(0, 4).map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                No featured properties available at the moment.
              </p>
            </div>
          )}

          <div className="mt-8 text-center md:hidden">
            <Button variant="outline" className="w-full font-medium" asChild>
              <Link href="/properties">View All Properties</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Discover Local */}
      <section className="py-24 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-12 text-center">
            More Than Just a Stay
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <Link
              href="/events"
              className="group relative h-[350px] rounded-2xl overflow-hidden cursor-pointer"
            >
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors z-10" />
              <img
                src="/images/coastal.png"
                alt="Local Events"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 z-20 flex flex-col justify-end p-8">
                <h3 className="text-3xl font-serif font-bold text-white mb-2">
                  Local Events
                </h3>
                <p className="text-white/90 text-lg">
                  Discover festivals, markets, and gatherings near your stay.
                </p>
              </div>
            </Link>

            <Link
              href="/shop"
              className="group relative h-[350px] rounded-2xl overflow-hidden cursor-pointer"
            >
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors z-10" />
              <img
                src="/images/apartment.png"
                alt="StayNest Shop"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 z-20 flex flex-col justify-end p-8">
                <h3 className="text-3xl font-serif font-bold text-white mb-2">
                  The staticholidays Shop
                </h3>
                <p className="text-white/90 text-lg">
                  Bring the holiday home with our curated collection.
                </p>
              </div>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
