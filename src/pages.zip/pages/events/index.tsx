import { useListEvents } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Tag } from "lucide-react";
import { format } from "date-fns";

export default function Events() {
  const { data: events, isLoading } = useListEvents();

  if (isLoading) return <div className="container mx-auto p-8">Loading events...</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-serif font-bold text-foreground mb-4">Local British Events</h1>
        <p className="text-lg text-muted-foreground">Discover festivals, markets, and gatherings happening near your stay.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events?.map(event => (
          <Link key={event.id} href={`/events/${event.id}`}>
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer overflow-hidden border-border group">
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={event.imageUrl || "/images/coastal.png"} 
                  alt={event.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <Badge className="absolute top-3 left-3 bg-background/90 text-foreground hover:bg-background/90 border-none">
                  {event.category}
                </Badge>
              </div>
              <CardContent className="p-5">
                <h3 className="text-xl font-serif font-bold mb-2 group-hover:text-primary transition-colors">{event.title}</h3>
                <div className="space-y-2 text-sm text-muted-foreground mb-4">
                  <p className="flex items-center gap-2"><Calendar className="h-4 w-4 text-primary/70"/> {format(new Date(event.date), "PPP")}</p>
                  <p className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary/70"/> {event.location}, {event.county}</p>
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-border">
                  <span className="font-bold text-foreground">{event.isFree ? "Free Entry" : `£${event.price}`}</span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
