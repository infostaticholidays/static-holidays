import { useGetEvent } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { Calendar, MapPin, Tag, User, Globe } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function EventDetail() {
  const { id } = useParams();
  const eventId = parseInt(id || "0", 10);
  const { data: event, isLoading } = useGetEvent(eventId, { query: { enabled: !!eventId } });

  if (isLoading) return <div className="container mx-auto p-8">Loading...</div>;
  if (!event) return <div className="container mx-auto p-8">Event not found</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="h-[400px] w-full rounded-2xl overflow-hidden mb-8">
        <img src={event.imageUrl || "/images/coastal.png"} alt={event.title} className="w-full h-full object-cover" />
      </div>
      
      <div className="flex flex-wrap gap-2 mb-4">
        <Badge className="bg-primary/10 text-primary border-none text-sm">{event.category}</Badge>
        {event.isFree && <Badge className="bg-green-500/10 text-green-700 border-none text-sm">Free Entry</Badge>}
      </div>

      <h1 className="text-4xl font-serif font-bold mb-6">{event.title}</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6 text-lg leading-relaxed text-muted-foreground">
          <p>{event.description}</p>
        </div>

        <div className="bg-muted/30 p-6 rounded-xl border border-border h-fit space-y-6">
          <div className="flex gap-3">
            <Calendar className="h-6 w-6 text-primary shrink-0" />
            <div>
              <p className="font-medium text-foreground">Date & Time</p>
              <p className="text-sm text-muted-foreground">{format(new Date(event.date), "PPP")}</p>
              <p className="text-sm text-muted-foreground">Until {format(new Date(event.endDate), "PPP")}</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <MapPin className="h-6 w-6 text-primary shrink-0" />
            <div>
              <p className="font-medium text-foreground">Location</p>
              <p className="text-sm text-muted-foreground">{event.location}</p>
              <p className="text-sm text-muted-foreground">{event.county}</p>
            </div>
          </div>

          <div className="flex gap-3">
            <User className="h-6 w-6 text-primary shrink-0" />
            <div>
              <p className="font-medium text-foreground">Organizer</p>
              <p className="text-sm text-muted-foreground">{event.organizer}</p>
            </div>
          </div>

          {!event.isFree && (
            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground mb-1">Tickets from</p>
              <p className="text-2xl font-bold text-foreground">£{event.price}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
